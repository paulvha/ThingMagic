/*
  Reading multiple RFID tags, simultaneously!
  By: Nathan Seidle @ SparkFun Electronics
  Date: October 3rd, 2016
  https://github.com/sparkfun/Simultaneous_RFID_Tag_Reader

  Constantly reads and outputs any tags heard

  If using the Simultaneous RFID Tag Reader (SRTR) shield, make sure the serial slide
  switch is in the 'SW-UART' position on the M6E or 'SER' on M7E

  July 2025 / paulvha
  ===================
  This example demonstrates 5 new GEN2 parameter functions. They can help to improve
  the quality of the communications between the tag and readers, as well as improve
  to perform an inventory. 
  These GEN2 parameters can be changed during reading to test the impact. 
  
  See the EXPLAINED tab for more information about the functions and the parameters.
  
  This Example30 is based on Example2 but it has GEN2 selection functions added.
*/

#include "SparkFun_UHF_RFID_Reader.h" //Library for controlling the M6E / M7E module

// By default, this example assumes software serial. If your platform does not
// support software serial, you can use hardware serial by commenting out these
// lines and changing the rfidSerial definition below
#include <SoftwareSerial.h>
SoftwareSerial softSerial(2, 3); //RX, TX

// Here you can specify which serial port the RFID module is connected to. This
// will be different on most platforms, so check what is needed for yours and
// adjust the definition as needed. Some examples are provided below
#define rfidSerial softSerial // Software serial (eg. Arduino Uno or SparkFun RedBoard)
//#define rfidSerial Serial1 // Hardware serial (eg. ESP32 or Teensy)

// Here you can select the baud rate for the module. 38400 is recommended if
// using software serial, and 115200 if using hardware serial.
#define rfidBaud 38400
// #define rfidBaud 115200

// Here you can select which module you are using. This library was originally
// written for the M6E Nano only, and that is the default if the module is not
// specified. Support for the M7E Hecto has since been added, which can be
// selected below
#define moduleType ThingMagic_M6E_NANO
// #define moduleType ThingMagic_M7E_HECTO

/////////////////////////////////////////////////////////////
/* define driver debug
 * 0 : no messages
 * 1 : request sending and receiving
*////////////////////////////////////////////////////////////
#define DEBUG 0

/////////////////////////////////////////////////////////////
/* define Region to operate
 * This will select the correct unlicensed frequency to use
 * in you area. Valid options :
 *
 * REGION_INDIA        REGION_JAPAN     REGION_CHINA
 * REGION_KOREA        REGION_AUSTRALIA REGION_NEWZEALAND
 * REGION_NORTHAMERICA REGION_EUROPE    REGION_OPEN
*////////////////////////////////////////////////////////////
#define RFIDREGION REGION_NORTHAMERICA

//***************************************************
//       NO CHANGES NEEDED BEYOND THIS POINT        *
//***************************************************

// Create instance of the RFID module
RFID rfidModule;

void setup()
{
  Serial.begin(115200);
  while (!Serial); //Wait for the serial port to come online

  Serial.println(F("Example31: Read and GEN2 parameters"));

  if (DEBUG) rfidModule.enableDebugging(Serial);

  if (setupRfidModule(rfidBaud) == false) 
  {
    Serial.println(F("Module failed to respond. Please check wiring."));
    while (1); //Freeze!
  }
  
  rfidModule.setRegion(RFIDREGION); //Set to the right region

  rfidModule.setReadPower(500); //27.00 dBm. Higher values may caues USB port to brown out
  //Max Read TX Power is 27.00 dBm and may cause temperature-limit throttling

  // set initial GEN2 values
  SetSession(TMR_GEN2_SESSION_S1);            // default is S0, S1 will show difference right away
  SetTarget(TMR_GEN2_TARGET_A);               // default is TARGET A
  
  if (moduleType == ThingMagic_M7E_HECTO)
    SetRFmode(TMR_GEN2_RFMODE_250_M4_20);     // nearly default 250 / M4 / 25

  disp_options();

  Serial.println(F("\nPress a key to begin scanning for tags.")); 
  
  flush();
  while (!Serial.available()); //Wait for user to send a character
  flush(); //Throw away the user's character
}

void disp_options()
{
  Serial.println(F("During inventory press:\n\ta <enter> for TARGET-A. \n\tb <enter> for TARGET-B search."));
  Serial.println(F("\tab <enter> for TARGET-AB. \n\tba <enter> for TARGET-BA search."));
  Serial.println(F("\ts0 - s3 <enter> to select different SESSION."));
  Serial.println(F("\tqd <enter> for Dynamic-Q. \n\tqs <enter> for Static-Q."));
  
  if (moduleType == ThingMagic_M7E_HECTO)
    Serial.println(F("\tr0 - r7 <enter> to select different RFMODE."));
    
  if (moduleType == ThingMagic_M6E_NANO){
    Serial.println(F("\tm0, m2, m4 or m8 for tag encoding."));   
  }

  Serial.println(F("NOT ALL COMBINATIONS OF THE GEN2 SETTINGS ARE SUPPORTED ON THE M6E AND M7E"));
  Serial.println(F("Documentation is not clear enough. Just try it.... "));
}

void loop()
{
  byte myEPC[12]; //Most EPCs are 12 bytes
  byte myEPClength;
  byte responseType = 0;

  while (responseType != RESPONSE_SUCCESS)//RESPONSE_IS_TAGFOUND)
  {
    Serial.println(F("Searching for tag"));
    myEPClength = sizeof(myEPC); //Length of EPC is modified each time .readTagEPC is called
    responseType = rfidModule.readTagEPC(myEPC, myEPClength, 500); //Scan for a new tag up to 500ms
    if (responseType != RESPONSE_SUCCESS) handleInput(false); 
  }

  //Print EPC
  Serial.print(F(" epc["));
  for (byte x = 0 ; x < myEPClength ; x++)
  {
    if (myEPC[x] < 0x10) Serial.print(F("0"));
    Serial.print(myEPC[x], HEX);
    Serial.print(F(" "));
  }
  Serial.println(F("]"));
  
  // check keyboard input for different GEN2 settings
  handleInput(false);    
}

/*
  Q-state is either TMR_SR_GEN2_Q_DYNAMIC or TMR_SR_GEN2_Q_STATIC

  Optional:
   init_value : initial Q-value to start
   set_init   : True = set init_value
*/
void setQ(TMR_SR_GEN2_QType Q_state, uint8_t init_value, bool set_init)
{
  if (!rfidModule.setGen2Q(Q_state, init_value, set_init)) {
    Serial.println(F("!!! ERROR !!! : Could not set GEN2 Q."));
  } 
}

/*
   Set Tag encoding ( NOT VALUE FOR M7E

   FM0  :  TMR_GEN2_FM0 = 0,             // only valid with 250Khz / 640Khz
   M = 2:  TMR_GEN2_MILLER_M_2 = 1,
   M = 4:  TMR_GEN2_MILLER_M_4 = 2,
   M = 8:  TMR_GEN2_MILLER_M_8 = 3,
*/
void SetTagEnc(TMR_GEN2_TagEncoding enc)
{
  if ( !rfidModule.setGen2Encoding(enc)) {
    Serial.println(F("!!! ERROR !!! : Could not set Tag encoding."));
  }
}

/**
  TMR_GEN2_SESSION_S0 = Session 0
  TMR_GEN2_SESSION_S1 = Session 1
  TMR_GEN2_SESSION_S2 = Session 2
  TMR_GEN2_SESSION_S3 = Session 3
 */
void SetSession(TMR_GEN2_Session session)
{
  if ( !rfidModule.setGen2Session(session)) {
    Serial.println(F("!!! ERROR !!! : Could not set Session."));
  }
}

/**
  TMR_GEN2_RFMODE_160_M8_20  Sets 160KHZ BLF, M8 TagEncoding and 20us Tari 
  TMR_GEN2_RFMODE_250_M4_20  Sets 250KHZ BLF, M4 TagEncoding and 20us Tari 
  TMR_GEN2_RFMODE_320_M2_15  ets 320KHZ BLF, M2 TagEncoding and 15us Tari 
  TMR_GEN2_RFMODE_320_M2_20  Sets 320KHZ BLF, M2 TagEncoding and 20us Tari 
  TMR_GEN2_RFMODE_320_M4_20  Sets 320KHZ BLF, M4 TagEncoding and 20us Tari 
  TMR_GEN2_RFMODE_640_FM0_7_5 Sets 640KHZ BLF, FM0 TagEncoding and 7.5us Tari
  TMR_GEN2_RFMODE_640_M2_7_5 Sets 640KHZ BLF, M2 TagEncoding and 7.5us Tari
  TMR_GEN2_RFMODE_640_M4_7_5 Sets 640KHZ BLF, M4 TagEncoding and 7.5us Tari
  NOT ALL IS SUPPORTED BY M7E
  
  NOT supported on M6E rfidModule.begin MUST have been started with ThingMagic_M7E_NANO
*/
void SetRFmode(TMR_GEN2_RFMode rfmode)
{
  if (! rfidModule.setGen2RFmode(rfmode)) {
    Serial.println(F("!!! ERROR !!! : Could not set RFMODE."));
  }
}

/** 
  TMR_GEN2_TARGET_A  : Search target A 
  TMR_GEN2_TARGET_B  : Search target B 
  TMR_GEN2_TARGET_AB : Search target A until exhausted, then search target B 
  TMR_GEN2_TARGET_BA : Search target B until exhausted, then search target A
*/
void SetTarget(TMR_GEN2_Target target)
{
  if (! rfidModule.setGen2Target(target)) {
    Serial.println(F("!!! ERROR !!! : Could not set TARGET."));
  }
}

// flush pending serial input
// every MCU seems to need different delays.
void flush()
{
  delay(100);
  while (Serial.available()){
    Serial.read();
    delay(100);
  }
}

/**
 * handle any keyboard input.
 * @parameter StopStart
 *  true  : stop and start continous reading
 *  false : no action
 */
void handleInput(bool StopStart)
{
  char c, d = 0xf;
  
  // check keyboard input
  if (! Serial.available()) return;
  c = Serial.read();
  delay(100);
  
  if (Serial.available()) 
    d = Serial.read();

  flush();
  
  if (StopStart) rfidModule.stopReading();
  
  TMR_GEN2_Target t = TMR_GEN2_TARGET_INVALID;

  // check target
  if (c == 'a') {
    
    if (d == 'b'){
      Serial.println(F("Set Target AB"));
      t = TMR_GEN2_TARGET_AB;
    }
    else {
      Serial.println(F("Set Target A"));
      t = TMR_GEN2_TARGET_A;
    }
  }
    
  else if (c == 'b') {
    if (d == 'a'){
      Serial.println(F("Set Target BA"));
      t = TMR_GEN2_TARGET_BA;
    }
    else {
      Serial.println(F("Set Target B"));
      t = TMR_GEN2_TARGET_B;
    }    
  }

  if (t != TMR_GEN2_TARGET_INVALID) {
    SetTarget(t);
    goto ReadResume;
  }
  
  // check RFMODE
  if (c == 'r')
  {
    if (moduleType == ThingMagic_M6E_NANO){
      Serial.println(F("RFMODE setting NOT supported on M6E"));
      goto ReadResume;
    }
      
    TMR_GEN2_RFMode m = TMR_GEN2_RFMODE_INVALID;
    
    switch(d)
    {
      case '0':
        Serial.println(F("Set 160KHZ BLF, M8 TagEncoding and 20us Tari"));
        m = TMR_GEN2_RFMODE_160_M8_20;
        break;
      
      case '1':
        Serial.println(F("Set 250KHZ BLF, M4 TagEncoding and 20us Tari"));
        m = TMR_GEN2_RFMODE_250_M4_20;
        break;
      
      case '2':
        Serial.println(F("Set 320KHZ BLF, M2 TagEncoding and 15us Tari"));
        m = TMR_GEN2_RFMODE_320_M2_15;
        break;
      
      case '3':
        Serial.println(F("Set 320KHZ BLF, M2 TagEncoding and 20us Tari"));
        m = TMR_GEN2_RFMODE_320_M2_20;
        break;

      case '4':
        Serial.println(F("Set 320KHZ BLF, M4 TagEncoding and 20us Tari"));
        m = TMR_GEN2_RFMODE_320_M4_20;
        break;
      
      case '5':
        Serial.println(F("Set 640KHZ BLF, FM0 TagEncoding and 7.5us Tari"));
        m = TMR_GEN2_RFMODE_640_FM0_7_5;
        break;
      
      case '6':
        Serial.println(F("Set 640KHZ BLF, M2 TagEncoding and 7.5us Tari"));
        m = TMR_GEN2_RFMODE_640_M2_7_5;
        break;
      
      case '7':
        Serial.println(F("Set 640KHZ BLF, M4 TagEncoding and 7.5us Tari "));
        m = TMR_GEN2_RFMODE_640_M4_7_5;
        break;
      
      default:
        Serial.println(F("Invalid RFMODE requested"));
        break;
    }
  
    if (m != TMR_GEN2_RFMODE_INVALID)
        SetRFmode(m);

    goto ReadResume;
  }
  
  // check session
  else if (c == 's')
  {
    TMR_GEN2_Session s;
    
    switch(d)
    {
      case '0':
        Serial.println(F("Set Session 0"));
        s = TMR_GEN2_SESSION_S0;
        break;
    
     case '1':
        Serial.println(F("Set Session 1"));
        s = TMR_GEN2_SESSION_S1;
        break;
    
      case '2':
        Serial.println(F("Set Session 2"));
        s = TMR_GEN2_SESSION_S2;
        break;
    
     case '3':
        Serial.println(F("Set Session 3"));
        s = TMR_GEN2_SESSION_S3;
       break;
    
      default:
        Serial.println(F("Invalid Session request"));
        goto ReadResume;
        break;
    }
    
    SetSession(s);
    goto ReadResume;
  }
  
  // check Q-settings
  else if(c == 'q')
  {
    TMR_SR_GEN2_QType q;
    uint8_t init_value;
    bool set_init = false;
    
    switch(d)
    {
      case 'd':
        Serial.println(F("Set GEN2 Q Dynamic"));
        q = TMR_SR_GEN2_Q_DYNAMIC;
        break;
    
     case 's':
        Serial.println(F("Set GEN2 Q static"));
        q = TMR_SR_GEN2_Q_STATIC;
        break;
     
      default:
        Serial.println(F("Invalid GEN2 Q request"));
        goto ReadResume;
        break;
    }
  
    Serial.println(F("Do you want to set initial Q-value ? (y/n)"));
    while(! Serial.available());
    c = Serial.read();
    flush();
    
    uint8_t qmin = 1, qmax = 10;
    if (c == 'y' || c == 'Y') {
      if (q == TMR_SR_GEN2_Q_STATIC){
        Serial.println(F("Enter initial Static Q-value between 2 and 9. (within 10 seconds)"));
        qmin = 2;
        qmax = 9;
      }
      else {
        Serial.println(F("Enter initial Generic Q-value between 1 and 10. (within 10 seconds)"));
      }
      Serial.setTimeout(10000);   // wait 10 seconds
      String Keyb = Serial.readStringUntil(0x0a);
      
      if (Keyb.length() > 0 ) {
        init_value = Keyb.toInt();
        if (init_value < qmin || init_value > qmax) {
          Serial.print(init_value);
          Serial.println(F(" :Invalid initial Q-value"));
        }
        else
          set_init = true;
      }
      
      if (! set_init){
        Serial.println(F("No (valid) initial Q-value input. Only setting new Q-state"));
      }
    }
    setQ(q, init_value, set_init);
    goto ReadResume;
  }
  else if (c == 'm' || c == 'M')
  {
    TMR_GEN2_TagEncoding enc;
    
    if (moduleType == ThingMagic_M7E_HECTO) {
      Serial.println(F("Only for M6E, M7E supports RFMODE"));
      goto ReadResume;
    }
    
    switch(d)
    {
      case '0':
        Serial.println(F("Set Encoding FM0"));
        enc = TMR_GEN2_FM0;
        break;
    
     case '2':
        Serial.println(F("Set Encoding M2"));
        enc = TMR_GEN2_MILLER_M_2;
        break;

     case '4':
        Serial.println(F("Set Encoding M4"));
        enc = TMR_GEN2_MILLER_M_4;
        break;

     case '8':
        Serial.println(F("Set Encoding M8"));
        enc = TMR_GEN2_MILLER_M_8;
        break;
        
      default:
        Serial.println(F("Invalid Tag encoding request"));
        goto ReadResume;
        break;
    }
    SetTagEnc(enc);
  }
  
ReadResume:
  if (StopStart)  rfidModule.startReading(); //Begin scanning for tags
  disp_options();
}

//Gracefully handles a reader that is already configured and already reading continuously
//Because Stream does not have a .begin() we have to do this outside the library
boolean setupRfidModule(long baudRate)
{
  rfidModule.begin(rfidSerial, moduleType); //Tell the library to communicate over serial port

  //Test to see if we are already connected to a module
  //This would be the case if the Arduino has been reprogrammed and the module has stayed powered
  rfidSerial.begin(baudRate); //For this test, assume module is already at our desired baud rate
  delay(200);

  //About 200ms from power on the module will send its firmware version at 115200. We need to ignore this.
  while(rfidSerial.available()) rfidSerial.read();

  rfidModule.getVersion();

  if (rfidModule.msg[0] == ERROR_WRONG_OPCODE_RESPONSE)
  {
    //This happens if the baud rate is correct but the module is doing a ccontinuous read
    rfidModule.stopReading();

    Serial.println(F("Module continuously reading. Asking it to stop..."));

    delay(1500);
  }

  else if (rfidModule.msg[0] != ALL_GOOD)
  {
    //The module did not respond so assume it's just been powered on and communicating at 115200bps
    rfidSerial.begin(115200); //Start serial at 115200

    rfidModule.setBaud(baudRate); //Tell the module to go to the chosen baud rate. Ignore the response msg

    rfidSerial.begin(baudRate); //Start the serial port, this time at user's chosen baud rate

    //Test the connection
    rfidModule.getVersion();
    if (rfidModule.msg[0] != ALL_GOOD) return (false); //Something is not right
  }

  //The M6E has these settings no matter what
  rfidModule.setTagProtocol(); //Set protocol to GEN2

  rfidModule.setAntennaPort(); //Set TX/RX antenna ports to 1

  return (true); //We are ready to rock
}
