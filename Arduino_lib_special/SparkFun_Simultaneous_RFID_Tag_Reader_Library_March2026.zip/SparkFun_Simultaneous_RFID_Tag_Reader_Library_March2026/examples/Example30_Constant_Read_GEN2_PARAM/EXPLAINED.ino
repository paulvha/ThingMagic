/**
 * July 2025 / paulvha

Below I will try to explain the 5 new GEN2 parameters functions that I have added.  They can improve
the quality of the inventory of the GEN2 tags. it is a simplified version of the many articles and GEN2 
definitions that I have been reading.

3 functions have been added :
    bool setGen2Session(TMR_GEN2_Session session);
    bool setGen2Target(TMR_GEN2_Target target);
    bool setGen2Q(TMR_SR_GEN2_QType Q_state, uint8_t init_value = 0, bool set_init = false);
    
    bool setGen2Encoding(TMR_GEN2_TagEncoding enc); // NOT supported on M7E
    bool setGen2RFmode(TMR_GEN2_RFMode mode);       // NOT supported on M6E
    
Background
==========
Reader-to-Tag Communication can be impacted by setting Tari.
Tag-to-Reader Communication can be impacted by BLF and TagEncoding
Collisions can be impacted by Q, Session and Target.

On an M6E Nano Q, session, target and TAG encoding can be set
On an M6E Nano, the TARI is fixed to 25us and BLF 250Khz
An M6e starts with Q = dynamic, Session = S0, Tag encoding M-4

On an M7E Q, session, target and pre-defined combination BLF/Tag encoding/Tari can be set

Short description
=================
Set Session S0, Target-A to repeat read tags, often the same tag.
Set Session S1, Target-A to read tags, often more different tags.
Set Session S2 or S3, Target-A to read all the tags, the tags read stay "silent". Set Target-B to re-read the
tags again.

Add extra power supply and increase the read-power to increase the range to read more tags. Keep in mind
that the RFID reader will get hot and might need a cooling block

Sessions
========
The tag sessions are defined by the EPC Gen 2 standard for an RFID tag. 
All compliant tags will support this feature. The tag sessions are used for two things, 
specify how long after a read a tag will respond to another inventory request by a reader, 
and the second is to allow multiple readers to inventory a tag at the same time. 

Each session has two inventory states: A ("ready" state) and B. ("busy" state)
When a tag is inventoried by a reader the selected tag session will switch from the default state-A 
to the inventoried state-B. It will stay in the B state for the EPC defined length of time for that 
session, and in general will not respond to a reader again for the defined length of time for that session.

Think of sessions in a TAG as 4 variables: S0, S1, S2 and S3. The variable is either set as A or B. 
When a reader starts the inventory it can make a selection of the TAGS to respond based on the value in 
either S0, S1, S2 or S3. 
So it can look for TAGS of which the S1 value is A to respond only. Once it responded the S1 value
turns from A to B. That TAG will not respond anymore during this inventory as long as S1 = B.

Here are more details:
    • Session 0: Instructs the tag to reset the state to A every time it is inventoried. 
      This is required if you want to read the tag numerous times, and is not optimal for inventorying 
      a large number of tags because all of the tags will be responding continuously. This is the default
      approach for the M6E / M7E, hence you see the same TAG very often.
      
    • Session 1: After inventoried the tag stays in state B for a MAXIMUM of 5 seconds before returning to A. 
      This will reduce the amount of reads of a single tag as an inventory is in progress. Now it is easier
      to get other tags to respond, that maybe further away. 
      The time is defined in the EPC GEN 2 standard as being between 500ms and 5 seconds. You can NOT set
      this time. It is determined by the tag.
      
    • Session 2 and 3: These two sessions have the same definition. 
      After inventoried the tag stays in the B state for at least 2 seconds. 
      
      These two sessions are optimal for larger number of tags when you want to keep them 'quiet' 
      after they have responded to the inventory. 
      The Time is only required by the EPC GEN 2 standard to be a minimum of 2 seconds with no maximum defined; 
      it tends to be around 60 seconds but can be on the order of hundreds of seconds. The exact time is 
      determined by the tag itself, but it is not indefinite.
      
      Remember that during the time is state B, the tag will not respond to a query from any reader using 
      Target-A and the same inventory session. This prevents the same tag from being counted multiple times 
      during an inventory round. However if you now start a new session with Target-B, the tag will respond
      and set to state-A.

Now you may wonder why are Session 2 and 3 the same. Why do need both? Think about a situation where there 
are 2 readers trying to make an inventory of the same RFID's. Reader 1 starts and is then using S2 to make
the inventory, once done / stops, reader 2 starts and makes the inventory with S3. They do not impact 
each other.

Targets
=======

As written above a tag session (think variable) S0, S1, S2 or S3 can be in state A or B. When using Session 
S0 or S1, after inventoried the state will automatically move back from B to A. In case of S0 it will move 
back the state immediately, like it never moved to B, in case of S1 after a time that is below 5 seconds.

However with S2 and S3 the tags stay in B, for an unknown time, but longer that 2 seconds. Even AFTER the
read power was switched off, the S2 and S3 status continue B.

You can now set a session to target the tags in a certain state to respond :
state A OR state B  (also called Single Target)
First get all tags to respond in state A, followed by a search in B,  (Dual target)
First get all tags to respond in state B, followed by a search in A,  (Dual target)

Remarks
-------
Doing S0 or S1, with TARGET-B will not result in any (S0, S1 always A at start-up)
Doing S0 with TARGET-A, TARGET-AB or TARGET-BA, will cause same reading the same TAGS.
Doing S1 with TARGET-A, will cause other TAGS to be detected, but at slower speed.
Doing S1 with TARGET-AB or TARGET-BA, will cause a lot of reading the same TAGS.
Doing S2 or S3, with TARGET-A will read a TAG that was in state A only ONCE, as they switch to state B.
Doing S2 or S3, with TARGET-B will read a TAG that was in state B only ONCE, as they switch to state A.
Doing S2 or S3, with TARGET-AB or TARGET-BA will cause a lot or reading of different tags 


RFMODE
======
!!!!! M7E ONLY !!!!!

The RFMODE setting can be used to fine tune the radio signal to have a better quality communication between
the TAG and the reader.  A number of tags provide information else you can play around and see whether
it makes a difference.

BLF stands for Backscatter Link Frequency. It refers to the frequency at which an RFID tag modulates 
its reflected signal back to the reader. This frequency is crucial for communication between the tag
and the reader, and variations in BLF can impact system performance

Tari (Type A Reference Interval) is a crucial parameter that defines the duration of a pulse used to 
represent a binary "0" in the communication between an RFID reader and tag. Specifically, it's a timing 
element in the EPC Gen 2 protocol, which uses pulse interval encoding (PIE) to transmit data.

Tag encoding
============

In EPC Gen2, the tag can use one of several Miller encoding formats to respond, 
depending on what the reader supports:

Encoding Type  Description                            Use Case
FM0            Fastest, used at high data rates       Short-range, fast responses
Miller         M=2  Miller encoding with 2 cycles/bit Balanced speed & reliability
Miller         M=4  4 cycles per bit                  More robust, slower speed
Miller         M=8  8 cycles per bit                  Most robust, slowest speed


Q explained (by AI)
==================

In RFID systems, "Q" refers to a parameter that determines the length of time slots in a slotted ALOHA 
protocol, which is used for anti-collision. Dynamic Q adjusts this parameter in real-time based on tag 
behavior, while static Q uses a fixed value. Dynamic Q is generally preferred in scenarios with varying 
numbers of tags or where tags are moving, as it can improve system efficiency. 

Here's a more detailed breakdown:
Static Q:

    Uses a pre-defined, constant value for the parameter Q. 

    Suitable for scenarios where the number of tags and their behavior are relatively predictable and 
    consistent. Can be less efficient in dynamic environments where the number of tags or their movement 
    patterns change. 

Dynamic Q:

    Adjusts the value of Q dynamically based on the number of tags and their behavior. 

    Typically, the system increases Q when collisions are frequent (many tags are trying to transmit at 
    the same time) and decreases Q when there are many idle slots (few tags are transmitting). 
    More efficient in dynamic environments, leading to higher throughput and reduced read times. 
    The complexity of the system increases due to the need for monitoring and adjusting the parameter. 

Examples of dynamic Q algorithms include adaptive Q algorithms and those using posteriori probability tag 
estimation. 

Key Differences Summarized:
Feature       Static Q                      Dynamic Q
Q Value       Fixed                         Adjustable
Tag Behavior  Predictable                   Variable
Efficiency    Lower in dynamic environments Higher in dynamic environments
Complexity    Lower                         Higher

In essence, dynamic Q is a more sophisticated approach that adapts to changing conditions, 
while static Q provides a simpler solution for stable environments

*/
