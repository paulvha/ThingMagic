/*
  This sketch will enable you to select a TAG based on it's EPC (or part of the EPC) and then read
  the data for a specified bank at a specified offset within the bank of a specified length.

  Version 1.0 / December 2022 / paulvha
  * Initial version which is based on some of previous examples

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
*/

#include "SparkFun_UHF_RFID_Reader.h" //Library for controlling the M6E / M7E module

// By default, this example assumes software serial. If your platform does not
// support software serial, you can use hardware serial by commenting out these
// lines and changing the rfidSerial definition below
#include <SoftwareSerial.h>
SoftwareSerial softSerial(2, 3); //RX, TX

// Here you can specify which serial port the RFID module is connected to. This
// will be different on most platforms, so check what is needed for yours and
// adjust the definition as needed. Some examples are provided below
#define rfidSerial softSerial // Software serial (eg. Arudino Uno or SparkFun RedBoard)
//#define rfidSerial Serial1 // Hardware serial (eg. ESP32 or Teensy)

// Here you can select the baud rate for the module. 38400 is recommended if
// using software serial, and 115200 if using hardware serial.
#define rfidBaud 38400
// #define rfidBaud 115200

// Here you can select which module you are using. This library was originally
// written for the M6E Nano only, and that is the default if the module is not
// specified. Support for the M7E Hecto has since been added, which can be
// selected below
// #define moduleType ThingMagic_M6E_NANO
#define moduleType ThingMagic_M7E_HECTO

/////////////////////////////////////////////////////////////
/* define driver debug
 * 0 : no messages
 * 1 : request sending and receiving
*////////////////////////////////////////////////////////////
#define DEBUG 0

/////////////////////////////////////////////////////////////
/* define Region to operate
 * This will select the correct unlicensed frequency to use
 * in you area. Valid options :
 *
 * REGION_INDIA        REGION_JAPAN     REGION_CHINA
 * REGION_KOREA        REGION_AUSTRALIA REGION_NEWZEALAND
 * REGION_NORTHAMERICA REGION_EUROPE    REGION_OPEN
*////////////////////////////////////////////////////////////
#define RFIDREGION REGION_NORTHAMERICA

/////////////////////////////////////////////////////////////
//  Information for the TAG / EPC to select
//  !!!!!!!!!!!! ADJUST TO YOUR TAG !!!!!!!!!!!!!!!!!!!
/////////////////////////////////////////////////////////////
#define FULL_EPC        // it will take the full EPC for selecting the TAG

#ifdef FULL_EPC

uint8_t EPCToSelect[] = {0xE2,0x00,0x00,0x15,0x86,0x0E,0x02,0x88,0x15,0x40,0x29,0x80};
#define EPCMatchLength  sizeof(EPCToSelect)          // bytes of EPCToSelect (max. 12)
#define EPCMatchOffset  12 - EPCMatchLength          // bytes offset in EPC to select (max. 11)

#else // only match a portion of the TAG's EPC (allowing MORE TAGS to comply)

uint8_t EPCToSelect[] = {0x86,0x0E,0x02,0x88,0x15,0x40};
#define EPCMatchLength  sizeof(EPCToSelect)          // bytes of EPCToSelect (max. 12)
#define EPCMatchOffset  4                            // bytes offset in EPC to select (start at 4)

#endif

// uncomment line below to only try EPCRetryCount times to get the right TAG / EPC, else it is endless
//#define EPCRetryCount 20                             // try 20 times

//***************************************************
//       NO CHANGES NEEDED BEYOND THIS POINT        *
//***************************************************

RFID rfidModule; //Create instance
struct SelectEPC epcSelect;

void setup()
{
  Serial.begin(115200);
  while (!Serial); //Wait for the serial port to come online

  Serial.println(F("Example20: read selected TAG bank data region"));

  if (DEBUG) rfidModule.enableDebugging(Serial);

  if (setupRfidModule(rfidBaud) == false)
  {
    Serial.println(F("Module failed to respond. Please check wiring."));
    while (1); //Freeze!
  }

  rfidModule.setRegion(RFIDREGION); //Set to the right region

  rfidModule.setReadPower(500); //5.00 dBm. Higher values may cause USB port to brown out
  //Max Read TX Power is 27.00 dBm and may cause temperature-limit throttling

  // set the TAG selection info
  InitializeSelection();
}

void loop()
{
  flush();
  Serial.println(F("Press a key to read user data"));
  while (!Serial.available()); //Wait for user to send a character

  //Read the data from the tag
  byte responseType;
  byte myData[128];                    // Store the data from the requested Tag memory
  byte myDataLength = sizeof(myData);  // Tell SelectiveReadDataRegion to read up to Mydata bytes, or less

  uint32_t WordStartAdress = 0;        // skip byte 0 and 1, start at byte 2
  uint8_t  RegionLength = 16;          // number of words to read 16 words = 32 bytes

  int Bank = TMR_GEN2_BANK_USER;       // other options : TMR_GEN2_BANK_EPC, TMR_GEN2_BANK_TID, TMR_GEN2_BANK_RESERVED

  /* upon returnmyDataLength will be overwritten and set to the number of bytes read. Expected should be Regionlength (words) * 2 */
  responseType = rfidModule.SelectiveReadDataRegion(&epcSelect, Bank, WordStartAdress, RegionLength, myData, myDataLength);

  if (responseType == RESPONSE_SUCCESS)  {

    //Print results
    Serial.print(F("Read size (bytes) ["));
    Serial.print(myDataLength);

    switch(Bank) {
      case TMR_GEN2_BANK_EPC:
        Serial.print(F("] EPC data["));
        break;
      case TMR_GEN2_BANK_USER:
        Serial.print(F("] USER data["));
        break;
      case TMR_GEN2_BANK_TID:
        Serial.print(F("] TID data["));
        break;
      case TMR_GEN2_BANK_RESERVED:
        Serial.print(F("] RESERVED data["));
        break;
    }

    for (byte x = 0 ; x < myDataLength ; x++)
    {
      if (myData[x] < 0x10) Serial.print(F("0"));
      Serial.print(myData[x], HEX);
      Serial.print(F(" "));
    }
    Serial.println(F("]"));
  }

  else if (responseType == ERROR_INVALID_EPC_REQ) {
    Serial.println(F("Error: In requested EPC offset or length"));
  }

  else if (responseType == ERROR_INVALID_REQ) {
    Serial.println(F("Error: In request bank offset or length"));
  }

  else if (responseType == RESPONSE_FAIL) {
    Serial.println(F("Error: During reading tag"));
  }

  else if (responseType == ERROR_COMMAND_RESPONSE_TIMEOUT) {
    Serial.println(F("Error: Exceeded retry count"));
  }
  else
    Serial.println(F("Error: Unknown"));
}

//Gracefully handles a reader that is already configured and already reading continuously
//Because Stream does not have a .begin() we have to do this outside the library
boolean setupRfidModule(long baudRate)
{
  rfidModule.begin(rfidSerial, moduleType); //Tell the library to communicate over serial

  //Test to see if we are already connected to a module
  //This would be the case if the Arduino has been reprogrammed and the module has stayed powered
  rfidSerial.begin(baudRate); //For this test, assume module is already at our desired baud rate
  delay(200); //Wait for port to open

  //About 200ms from power on the module will send its firmware version at 115200. We need to ignore this.
  while(rfidSerial.available()) rfidSerial.read();

  rfidModule.getVersion();

  if (rfidModule.msg[0] == ERROR_WRONG_OPCODE_RESPONSE)
  {
    //This happens if the baud rate is correct but the module is doing a ccontinuous read
    rfidModule.stopReading();

    Serial.println(F("Module continuously reading. Asking it to stop..."));

    delay(1500);
  }

  else if (rfidModule.msg[0] != ALL_GOOD)
  {
    //The module did not respond so assume it's just been powered on and communicating at 115200bps
    rfidSerial.begin(115200); //Start software serial at 115200

    rfidModule.setBaud(baudRate); //Tell the module to go to the chosen baud rate. Ignore the response msg

    rfidSerial.begin(baudRate); //Start the serial port, this time at user's chosen baud rate

    //Test the connection
    rfidModule.getVersion();
    if (rfidModule.msg[0] != ALL_GOOD) return (false); //Something is not right
  }

  //The M&E / M6E has these settings no matter what
  rfidModule.setTagProtocol(); //Set protocol to GEN2

  rfidModule.setAntennaPort(); //Set TX/RX antenna ports to 1

  return (true); //We are ready to rock
}

/**
 * initialize the TAG / EPC to find.
 *
 * The match data is stored in a structure
 *
 * typedef struct SelectEPC {
 *  uint8_t TMR_EPC[12];        // EPC bytes or part of the EPC to match
 * uint8_t EPClen;         // length of the EPC bytes or part (max 12)
 * uint8_t EPCoffset;      // offset to start matching EPC or part (max 11)
 * uint8_t RetryCount;     // how to to retry (0 is continuous)
 * };
 */
void InitializeSelection()
{
#ifdef DEBUG == 1
  Serial.print("Look for EPC values with length of ");
  Serial.print(EPCMatchLength);
  Serial.print(" Starting at offset ");
  Serial.println(EPCMatchOffset);
#endif

  if (EPCMatchLength + EPCMatchOffset > 12 || EPCMatchLength > 12) {
    Serial.println("EPCMatchLength too long. Freeze! \n");
    while(1);
  }

  epcSelect.EPCoffset = EPCMatchOffset;
  epcSelect.EPClen = EPCMatchLength;

  for (uint8_t i=0 ; i < EPCMatchLength ; i++) {
    epcSelect.TMR_EPC[i] =  EPCToSelect[i];
#ifdef DEBUG == 1
    Serial.print(EPCToSelect[i], HEX);    // display
    Serial.print(" ");
  }
  Serial.println();
#else
  }
#endif

#ifdef EPCRetryCount
  epcSelect.RetryCount = EPCRetryCount;    // Try for RetryCount times before returning
#else
  epcSelect.RetryCount = 0;                // endless
#endif

}

/**
 * flush any pending input
 */
void flush()
{
  while ( Serial.available()) {
    Serial.read();
    delay(100);
  }
}
